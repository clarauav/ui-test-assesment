# Definition
At employees.html the following client requirement has been implemented:
- The possibility to see the city of origin of the selected employees in a list.

# Task
Define and implement the tests you think are necessary for the technology you prefer.
